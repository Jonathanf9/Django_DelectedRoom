from django.contrib import admin
from app.models import Task

admin.site.register(Task)
